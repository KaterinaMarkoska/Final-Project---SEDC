package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AddProductsInCartTests extends BaseTests {


    @Test
    public void addProductsTest() throws InterruptedException {
        addProductsInCartPage.navigateToProductsPage();
        Thread.sleep(2000);
        addProductsInCartPage.clickDressesButton();
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,300)", "");
        addProductsInCartPage.clickPrintedDressButton();
        addProductsInCartPage.switchToWindow();
        Thread.sleep(2000);
        addProductsInCartPage.clickAddToCartButton();
        addProductsInCartPage.switchToMainPage();
        Assert.assertEquals(addProductsInCartPage.validateTextProductInShoppingCart(), "Product successfully added to your shopping cart");
        Assert.assertEquals(addProductsInCartPage.validateProductName(), "Printed Dress");
        Assert.assertEquals(addProductsInCartPage.validateSizeAndColor(),"S, Orange");
        addProductsInCartPage.clickContinueShoppingButton();
        addProductsInCartPage.clickDressesButton();
        addProductsInCartPage.clickSummerDresses();
        js.executeScript("window.scrollBy(0,300)", "");
        addProductsInCartPage.clickPrintedSummerDressButton();
        addProductsInCartPage.switchToWindow();
        Assert.assertEquals(addProductsInCartPage.validateShortDressDescription(),"Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.");
        Assert.assertEquals(addProductsInCartPage.validateDressCondition(), "Condition: New product");
        addProductsInCartPage.clickQuantityButton();
        addProductsInCartPage.clickAddToCartButton();
        addProductsInCartPage.switchToMainPage();
        Assert.assertEquals(addProductsInCartPage.validateTextProductInShoppingCart(), "Product successfully added to your shopping cart");
        Assert.assertEquals(addProductsInCartPage.validateProductName(), "Printed Summer Dress");
        Assert.assertEquals(addProductsInCartPage.validateSizeAndColor(),"S, Yellow");
        Thread.sleep(2000);
        addProductsInCartPage.clickProceedToCheckoutButton();





    }
}
