package pageObjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;

public class AddProductsInCartPage {
    private WebDriver driver;
    private WebDriverWait wait;


    private AddProductsInCartPage addProductsInCart;
    private By dressButtonLocator = By.xpath("//*[@id='block_top_menu']/ul/li[2]/a");
    private By printedDressButtonLocator = By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[1]/div/a[1]");
    private By sizePrintedDressLocator = By.xpath("//*[@id='uniform-group_1']");
    private By addToCartLocator = By.xpath("//*[@id='add_to_cart']/button/span");
    private By switchToIFrameWindow = By.xpath("//iframe[contains(@class,'fancybox-iframe')]");
    private By continueShoppingLocator = By.xpath("//*[@title='Continue shopping']/span");
    private By validateProductAddedToCartLocator = By.xpath("//*[@class='icon-check']\t/..");
    private By validateSizeAndColorLocator = By.xpath("//*[@id='layer_cart_product_attributes']");
    private By validateProductNameLocator = By.xpath("//*[@id='layer_cart_product_title']");
    private By summerDressesLocator = By.xpath("//*[@class='tree dynamized']/li[3]");
    private By printedSummerDressLocator = By.xpath("//*[@class=\"product_list grid row\"]/li/div/div/div/a");
    private By validateShortDressDescriptionLocator = By.xpath("//*[@class='buttons_bottom_block']/../div");
    private By validateDressConditionLocator = By.xpath("//*[@id='product_condition']");
    private By quantityButtonLocator = By.xpath("//*[@class='icon-plus']");
    private By proceedToCheckoutLocator = By.xpath("//*[@class='button-container']/a/span");
    public AddProductsInCartPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void navigateToProductsPage() {
        driver.navigate().to("http://www.automationpractice.pl/index.php");
    }

    public void clickDressesButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(dressButtonLocator)).click();
    }

    public void clickPrintedDressButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(printedDressButtonLocator)).click();
    }
    public void switchToWindow() {
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(switchToIFrameWindow));
    }

    public void selectDressSize(String text) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(sizePrintedDressLocator)).sendKeys(text);
    }

    public void clickAddToCartButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartLocator)).click();
    }
    public void switchToMainPage() {
        driver.switchTo().defaultContent();
    }
    public void clickContinueShoppingButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(continueShoppingLocator)).click();
    }
    public String validateTextProductInShoppingCart (){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(validateProductAddedToCartLocator)).getText();
    }
    public String validateProductName (){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(validateProductNameLocator)).getText();
    }
    public String validateSizeAndColor (){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(validateSizeAndColorLocator)).getText();
    }
    public void clickSummerDresses() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(summerDressesLocator)).click();
    }
    public void clickPrintedSummerDressButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(printedSummerDressLocator)).click();
    }
    public String validateShortDressDescription (){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(validateShortDressDescriptionLocator)).getText();
    }
    public String validateDressCondition (){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(validateDressConditionLocator)).getText();
    }
    public void clickQuantityButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(quantityButtonLocator)).click();
    }
    public void clickProceedToCheckoutButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(proceedToCheckoutLocator)).click();
    }


}
